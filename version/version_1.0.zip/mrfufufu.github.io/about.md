---
layout: page
title: About
permalink: /about/
description: "Hey, this is MrFuFuFu."
header-img: "img/about-bg.jpg"
---

我叫傅圆，我是一名来自中国的 Android 开发者，你可以通过这些地方找到我或者看到我，^ ^

<mrfuyuan@gmail.com> 

[Github](https://github.com/MrFuFuFu)

[LinkedIn](https://cn.linkedin.com/pub/yuan-fu/bb/69/368)

[简书](http://www.jianshu.com/users/c1b9d1faa7b5/latest_articles)

[Facebook](https://www.facebook.com/profile.php?id=100006538561748)

[Twitter](https://twitter.com/15068728607)

[Instagram](https://instagram.com/mrfufufufu/)

[知乎](http://www.zhihu.com/people/fu-yuan-58)

[扇贝](http://www.shanbay.com/bdc/review/progress/12563734 )

[CSDN](http://blog.csdn.net/fu222cs98)





